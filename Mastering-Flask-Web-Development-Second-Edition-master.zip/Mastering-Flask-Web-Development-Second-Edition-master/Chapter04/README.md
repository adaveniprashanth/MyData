Chapter 4 - Creating Controllers with blueprints
================================================

To run the application
----------------------

```
./init.sh
export FLASK_APP=main.py
flask run
```
