Chapter 2 - Creating Models with SQLAlchemy
===========================================

To run the application
----------------------

```
./init.sh
source venv/bin/activate
export FLASK_APP=main.py
flask run
```
