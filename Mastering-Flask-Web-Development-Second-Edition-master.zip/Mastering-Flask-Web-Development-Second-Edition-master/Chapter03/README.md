Chapter 3 - Creating Views with template
========================================

To run the application
----------------------

```
./init.sh
export FLASK_APP=main.py
flask run
```
