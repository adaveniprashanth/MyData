DIR=./Flask-YouTube
cd $DIR
python3 setup.py build
python3 setup.py install

