Chapter 11 -  Building Your Own Extension
=========================================


To run the application
----------------------

```
./init.sh
source venv/bin/activate
export FLASK_APP=main.py
flask run
```
