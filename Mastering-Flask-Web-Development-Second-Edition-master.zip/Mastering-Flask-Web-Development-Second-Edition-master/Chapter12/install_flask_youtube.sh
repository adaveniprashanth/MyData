DIR=./Flask-YouTube
cd $DIR
pip3 uninstall flask-youtube
python3 setup.py build
python3 setup.py install

