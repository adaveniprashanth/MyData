Chapter 10 - Useful Flask Extensions
====================================


To run the application
----------------------

```
./init.sh
source venv/bin/activate
export FLASK_APP=main.py
flask run
```
