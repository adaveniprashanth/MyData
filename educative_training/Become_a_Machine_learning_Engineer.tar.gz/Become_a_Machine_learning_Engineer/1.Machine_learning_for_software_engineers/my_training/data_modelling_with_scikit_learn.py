#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Sep 22 21:17:41 2020

@author: pj
"""
import numpy as np
import pandas as pd
from sklearn import linear_model
df = pd.read_excel('Grouping.xls',index_col=0,sheet_name='pizza_data')
pizza_data = df[['calories','weight_in_grams']].values #data set
pizza_price = df['price']#labels

if 0:#Linear Regression
    if 0:#what is linear Regression
        # finding an optimal model for a dataset is difficult, we instead try to find a good approximating distribution. In many cases, a linear model (a linear combination of the dataset's features) can approximate the data well. The term linear regression refers to using a linear model to represent the relationship between a set of independent variables and a dependent variable.
        
        #Y = ax1+bx2+cx3+d
        pass
    
    if 0:#Basic linear regression
        # The simplest form of linear regression is called least squares regression. This strategy produces a regression model, which is a linear combination of the independent variables, that minimizes the sum of squared residuals between the model's predictions and actual values for the dependent variable.
        
        reg = linear_model.LinearRegression()#calling the regression model
        reg.fit(pizza_data,pizza_price)#preparing the model with our data
        
        #Now the model is ready. we can give new values for testing
        new_pizzas = np.array([[2000,820],[2200,830]])
        print(repr(new_pizzas))
        
        prediceted_prices = reg.predict(new_pizzas)
        print(prediceted_prices)
        
        # Getting the co-efficients and intercept values
        print("co efficients {}\n".format(reg.coef_))
        print("intercept is {}\n".format(reg.intercept_))
        
        # Finally, we can retrieve the "coefficient of determination" (or R2 value) using the score function applied to the dataset and labels. The R2 value tells us how close of a fit the linear model is to the data, or in other words, how good of a fit the model is for the data.
        
        # Using previously defined pizza_data, pizza_prices
        r2 = reg.score(pizza_data, pizza_price)
        print('R2: {}\n'.format(r2))
        
        # The traditional R2 value is a real number between 0 and 1,where lower values denote a poorer model fit to the data. The closer the value is to 1, the better the model's fit on the data.

if 0:#Ridge Regression
    if 1:#
        # While ordinary least squares regression is a good way to fit a linear model onto a dataset, it relies on the fact that the dataset's features are each independent, i.e. uncorrelated. 
        # Because real life data tends to have noise, and will often have some linearly correlated features in the dataset, we combat this by performing regularization.
        # For regularization, the goal is to not only minimize the sum of squared residuals, but to do this with coefficients as small as possible. 
        pass
    
    if 0:#Choosing the best alpha(hyperparameter)
        reg = linear_model.Ridge(alpha=0.1)#manually adding the alphadefault value is 1
        reg.fit(pizza_data,pizza_price)
        print("co-efficients {}\n".format(reg.coef_))
        print("Intercept is {}\n".format(reg.intercept_))
        
        r2 = reg.score(pizza_data,pizza_price)
        print("R2 value is  {}\n".format(r2))
        
    if 1:#Choosing the proper alpha from list of alpha
        alphas = [0.1,0.4,0.6,0.7]
        reg = linear_model.RidgeCV(alphas=alphas)
        reg.fit(pizza_data,pizza_price)
        print("co-efficients {}\n".format(reg.coef_))
        print("Intercept is {}\n".format(reg.intercept_))
        
        r2 = reg.score(pizza_data,pizza_price)
        print("R2 value is  {}\n".format(r2))

if 0:# sparse linear regression via LASSO 
    if 1:# Sparse Regularization
        # Ridge regularization uses L2 norm penalty term but sparse regularization uses L1 norm for the weights penaluty term
        # LASSO regularization tends to prefer linear models with fewer parameter values. This means that it will likely zero-out some of the weight coefficients.
        pass
    
    if 1:#sparse regularization
        data = np.random.uniform(low=1.1,high=5.6,size=(150,4))
        # print(data)
        labels = pd.read_excel('Grouping.xls',sheet_name='Lasso_data')
        # print(labels)
        
        reg = linear_model.Lasso(alpha=0.1)
        reg.fit(data,labels)
        
        print("co-efficients are {}\n".format(reg.coef_))
        print("intercept is {}\n".format(reg.intercept_))
        print("R2 value is {}\n".format(reg.score(data,labels)))
        
if 1:#Bayesian Regression:
    if 1:#Bayesian techniques
        # In Bayesian statistics, the main idea is to make certain assumptions about the probability distributions of a model's parameters before being fitted on data. These initial distribution assumptions are called priors for the model's parameters.
        # In a Bayesian ridge regression model, there are two hyperparameters to optimize: α and λ. The α hyperparameter serves the same exact purpose as it does for regular ridge regression; namely, it acts as a scaling factor for the penalty term.
        # The λ hyperparameter acts as the precision of the model's weights. Basically, the smaller the λ value, the greater the variance between the individual weight values.
        pass
    
    if 1:#Hyperparameter priors
        # Both the α and λ hyperparameters have gamma distribution priors, meaning we assume both values come from a gamma probability distribution.
        # There's no need to know the specifics of a gamma distribution, other than the fact that it's a probability distribution defined by a shape parameter and scale parameter
        pass
    
    if 1:# Tuning the model
        data = np.random.uniform(low=1.1,high=5.6,size=(150,4))
        # print(data)
        labels = pd.read_excel('Grouping.xls',sheet_name='Lasso_data')
        # print(labels)
        
        reg = linear_model.BayesianRidge()
        reg.fit(data,labels)
        print('Coefficients: {}\n'.format(repr(reg.coef_)))
        print('Intercept: {}\n'.format(reg.intercept_))
        print('R2: {}\n'.format(reg.score(data, labels)))
        print('Alpha: {}\n'.format(reg.alpha_))
        print('Lambda: {}\n'.format(reg.lambda_))