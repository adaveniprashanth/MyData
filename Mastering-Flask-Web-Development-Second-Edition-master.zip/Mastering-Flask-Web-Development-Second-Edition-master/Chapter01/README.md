Chapter 1 - Getting Started
===========================

To run the application
----------------------

```
./init.sh
export FLASK_APP=main.py
flask run
```
